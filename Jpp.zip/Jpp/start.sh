cd workR/
python3 brain.py